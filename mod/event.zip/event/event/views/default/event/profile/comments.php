<?php
/**
 * Event Comments
 *
 * @uses $vars['entity']
 */
$causes = $vars['entity'];
echo elgg_view_comments($causes);