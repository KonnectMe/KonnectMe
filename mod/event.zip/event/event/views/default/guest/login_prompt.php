<div class="logintocomment" >
   
<a href="<?php echo SITE_URL;?>/login">Login</a> or <a href="<?php echo SITE_URL;?>register">Register</a> on KonnectMe fundraise, Create your pledge page and edit your tickets.
<br>
<br>
<strong>Just want to register and run then fill up the form below:</strong>
</div>