<?php
/**
 * Wrapper for site pages content area
 *
 * @uses $vars['content']
 */
echo "<div class='contentWrapper'>";
echo $vars['content'];
echo "</div>";