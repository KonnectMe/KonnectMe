    <link href="<?php echo VENDORS_PATH;?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="<?php echo VENDORS_PATH;?>bootstrap/js/bootstrap.min.js"></script>	
    <script src="<?php echo VENDORS_PATH;?>cufon/cufon-yui.js"></script>	
    <script src="<?php echo VENDORS_PATH;?>cufon/TitilliumText14L_300_600.font.js"></script>	
    <script src="<?php echo VENDORS_PATH;?>cufon/fontconfig.js"></script>	