<?php
/**
 *	Linen Theme for Elgg - A 1.8 premium theme for Elgg
 *	Author : Mahin Akbar | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com
 *	Skype : 'team.webgalli'
 *	@package linenElgg plugin
 *	Licence : GPLV2
 *	Copyright : Team Webgalli 2011-2015
 */
?> 
To add advertisement here edit the views/default/ads/slot1.php file. 