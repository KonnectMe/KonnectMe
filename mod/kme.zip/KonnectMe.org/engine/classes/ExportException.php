<?php
/**
 * Export exception
 *
 * @package    Elgg.Core
 * @subpackage Exception
 *
 */
class ExportException extends DataFormatException {}
