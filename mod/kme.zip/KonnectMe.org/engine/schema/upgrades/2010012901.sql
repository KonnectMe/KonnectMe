ALTER TABLE `prefix_entities` ADD `last_action` INT( 11 ) NOT NULL AFTER `time_updated` 
