<?php
elgg_delete_admin_notice('akismet_key');