<?php
/**
 * Layout of the event profile page
 *
 * @uses $vars['entity']
 */


echo elgg_view('causes/profile/summary', $vars);

echo elgg_view('causes/profile/widgets', $vars);

