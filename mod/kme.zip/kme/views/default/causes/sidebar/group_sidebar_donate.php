<?php
/**
 * Causes Donate
 *
 * @package Causes
 */
$cause = $vars['cause'];
if(!$cause){
	return;
}
set_input('causesid', $cause->guid);	
$body = elgg_view_form('causes/donate', array('entity' => $cause));
echo causes_view_module('aside', $cause->title, $body);
